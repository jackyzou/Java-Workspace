import javax.swing.JButton;
import javax.swing.JFrame;


public class main {


	public static void main(String[] args) {
		MasterClass MC = new MasterClass();
		
	//	SignUpPage signup = new SignUpPage();
	//	Home home = new Home();
		MC.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}
