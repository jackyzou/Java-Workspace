import javax.swing.JFrame;


public class Main {

	public static void main(String[] args) {
		HomePage a = new HomePage();
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
